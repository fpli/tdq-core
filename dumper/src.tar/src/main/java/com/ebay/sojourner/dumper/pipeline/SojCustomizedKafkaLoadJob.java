package com.ebay.sojourner.dumper.pipeline;

public class SojCustomizedKafkaLoadJob {

}
